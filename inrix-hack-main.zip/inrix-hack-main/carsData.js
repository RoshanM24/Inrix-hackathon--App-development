const carsData = {
    Petrol : {
        compact:34,
        midRange:27,
        Suv:23
    },
    Diesel : {
        compact:44,
        midRange:35,
        Suv:28
    },
    ef_gasoline : 8.8,
    ef_diesel : 10.1
}

module.exports = {
    carsData
}